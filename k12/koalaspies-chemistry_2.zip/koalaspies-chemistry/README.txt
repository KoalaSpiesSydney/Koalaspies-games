KOALASPIES CHEMISTRY GAMES - 2 October 2026

chemistrytable/
  Six finished game pages, set up to live at
  https://koalaspies-games.site/chemistrytable/

    element-symbols.html
    element-uses.html
    chem-common-names.html
    chem-atom-counts.html
    chem-ores.html
    chem-reactions.html

  NOT INCLUDED: the main chemistry page. Before you delete the old
  chemistry/table/ directory, save its index.html, rename it to
  k12chemistrytable.html and put it in this folder. Every game page
  links to it.

source-files-keep-on-your-computer/
  build_chem.py and chem_template.html. These are NOT for the website.
  Save them over your existing build script and template so the pages
  stay fixed the next time you rebuild. signs.py is no longer needed.
